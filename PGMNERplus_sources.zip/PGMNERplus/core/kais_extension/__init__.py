"""KAIS extension workspace package."""
